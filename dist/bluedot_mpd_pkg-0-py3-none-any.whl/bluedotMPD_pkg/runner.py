from bluedot import BlueDot
from signal import pause
from .MPD import MPDinit,MPDstop,MPDpause,MPDplay

def main():
	MPDinit(input('Host: ')) # point mpc call to host; also print MPD state
	bd = BlueDot(rows=3)
	bd[0,0].color="red"
	bd[0,1].color="yellow"
	bd[0,2].color="green"
	bd[0,0].when_pressed=MPDstop
	bd[0,1].when_pressed=MPDpause
	bd[0,2].when_pressed=MPDplay
	pause()
