# bluedot-mpd
Use python bluedot to start/stop/pause music player daemon running on an ancient raspberry pi with usb dongle for travel use (absent wifi MALP connection). 
